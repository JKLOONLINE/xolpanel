from xolpanel import *

#CREATE TROJAN
@bot.on(events.NewMessage(pattern=r"(?:.addtr|/addtr)$"))
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			masaaktif = masaaktif.wait_event(events.CallbackQuery)
			masaaktif = (await masaaktif).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{user}" "{masaaktif}" "{Quota}" "{iplim}" | addtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(masaaktif))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**     ⚡ ᴘʀᴇᴍɪᴜᴍ ᴛʀᴏᴊᴀɴ ᴀᴄᴄᴏᴜɴᴛ ⚡ **
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{user}`
**➣ Domain :** `{domain}`
**➣ User Quota :** `{Quota} GB`
**➣ Limit Ip:** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ Port TLS :** `443`
**➣ Host XrayDNS:** `{HOST}`
**➣ User ID :** `{uuid}`
**➣ PUB:** {PUB}
**━━━━━━━━━━━━━━━━━**
**                   TROJAN TLS    **
**━━━━━━━━━━━━━━━━━**
`{b[0].replace(" ","")}`
**━━━━━━━━━━━━━━━━**
**                   TROJAN No TLS
**━━━━━━━━━━━━━━━━**
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   TROJAN GRPC    **
**━━━━━━━━━━━━━━━━━**
`{b[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{domain}:81/trojan-{user}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired :** `{later}`
**➣ 🤖©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴛʀᴏᴊᴀɴ ᴍᴇɴᴜ","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#RENEW TROJAN
@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def renew_trojan(event):
	async def renew_trojan_(event):
	  
		x = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '#tr#' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as CLIENT_NUMBER:
			await event.respond('**Select one:**')
			CLIENT_NUMBER = CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			CLIENT_NUMBER = (await CLIENT_NUMBER).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond('**Exp (Days):**')
			masaaktif = masaaktif.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			masaaktif = (await masaaktif).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Renew Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{CLIENT_NUMBER}" "{masaaktif}" | renewtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#TRIALL TROJAN
@bot.on(events.NewMessage(pattern=r"(?:.trialtr|/trialtr)$"))
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Minutes ","10"),
Button.inline(" 15 Minutes ","15")],
[Button.inline(" 30 Minutes ","30"),
Button.inline(" 60 Minutes ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{Quota}" "{iplim}" "{exp}" | trialtr'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Triall Account`")
		time.sleep(1)
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			remarks = re.search("#(.*)",b[0]).group(1)
			domain = re.search("@(.*?):",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**    ⚡ ᴛʀɪᴀʟʟ ᴛʀᴏᴊᴀɴ ᴀᴄᴄᴏᴜɴᴛ ⚡ **
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{remarks}`
**➣ Domain :** `{domain}`
**➣ User Quota  :** `{Quota} GB`
**➣ Limit IP :** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ Port TLS :** `443`
**➣ Path Trojan :** `/trojan-ws`
**➣ User ID :** `{uuid}`
**➣ Host XrayDNS:** `{HOST}`
**➣ PUB:** {PUB}
**━━━━━━━━━━━━━━━━**
**                   TROJAN TLS     ** 
**━━━━━━━━━━━━━━━━**
`{b[0].replace(" ","")}`
**━━━━━━━━━━━━━━━━**
**                   TROJAN No TLS
**━━━━━━━━━━━━━━━━**
`{b[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━**
**                   TROJAN GRPC
**━━━━━━━━━━━━━━━━**
`{b[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{domain}:81/trojan-{remarks}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired Until:** `{exp} Minutes`
**➣ 🤖©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴛʀᴏᴊᴀɴ ᴍᴇɴᴜ","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#Delete TROJAN 
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
	  
		x = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '#tr#' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as CLIENT_NUMBER:
			await event.respond('**Select one:**')
			CLIENT_NUMBER = CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			CLIENT_NUMBER = (await CLIENT_NUMBER).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Delete Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{CLIENT_NUMBER}" | deltr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline(" ᴛʀɪᴀʟʟ ᴛʀᴏᴊᴀɴ ","trial-trojan"),
Button.inline(" ᴄʀᴇᴀᴛᴇ ᴛʀᴏᴊᴀɴ ","create-trojan")],
[Button.inline(" ᴅᴇʟᴇᴛᴇ ᴛʀᴏᴊᴀɴ ","delete-trojan"),
Button.inline(" ʀᴇɴᴇᴡ ᴛʀᴏᴊᴀɴ ","renew-trojan")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		tr = f' cat /etc/trojan/.trojan.db | grep "#tr#" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**   ⚡𝙏𝙍𝙊𝙅𝘼𝙉 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝙈𝙀𝙉𝙐 ⚡**
**━━━━━━━━━━━━━━━━━**
**  💻 Service:** `TROJAN`
**  🌎 ISP:** `{z["isp"]}`
**  🏢 Country:** `{z["country"]}`
**  🔗 Host:** `{DOMAIN}`
**  🤖 ©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
** TOTAL ACCOUNT TROJAN :** `{trj.strip()}` Account
**━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
