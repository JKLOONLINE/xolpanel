from xolpanel import *

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**━━━━━━━━━━━━━━━━━**
**              LOGIN VMESS**
**━━━━━━━━━━━━━━━━━**
```
{z}
```
**Shows Logged In Users Vmess**

""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

#CRATE VMESS
@bot.on(events.NewMessage(pattern=r"(?:.addws|/addws)$"))
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			masaaktif = masaaktif.wait_event(events.CallbackQuery)
			masaaktif = (await masaaktif).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{user}" "{masaaktif}" "{Quota}" "{iplim}" | addws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(masaaktif))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
#			c = [x.group() for x in re.finditer("Host XrayDNS(.*)",a)]
#			d = [x.group() for x in re.finditer("Pub Key(.*)",a)]
			print(b)
#			print(d)
#			print(c)
#			xx = re.search("Pub Key      :(.*)",d[0]).group(1)
#			xxx = re.search("Host XrayDNS :(.*)",d[0]).group(1)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**      ⚡ ᴘʀᴇᴍɪᴜᴍ ᴠᴍᴇꜱꜱ ᴀᴄᴄᴏᴜɴᴛ ⚡**
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{z["ps"]}`
**➣ Domain :** `{z["add"]}`
**➣ User Quota :** `{Quota} GB`
**➣ Limit IP :** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ port TLS :** `222-1000`
**➣ Port NTLS :** `80, 8080, 8081-9999`
**➣ Port GRPC :** `443`
**➣ AlterId :** `0`
**➣ Security :** `auto`
**➣ NetWork :** `(WS) or (gRPC)`
**➣ Path :** `/vmess`
**➣ Service Name :** `vmess`
**➣ User ID :** `{z["id"]}`
**➣ Host XrayDNS :** `{HOST}`
**➣ PUB :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS TLS     ** 
**━━━━━━━━━━━━━━━━━**
`{b[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS NTLS    ** 
**━━━━━━━━━━━━━━━━━**
`{b[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS GRPC    **
**━━━━━━━━━━━━━━━━━**
`{b[2].strip("'")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{DOMAIN}:81/vmess-{user}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired :** `{later}`
** 🤖 ©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴠᴍᴇꜱꜱ ᴍᴇɴᴜ","vmess")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.NewMessage(pattern=r"(?:.trialws|/trialws)$"))
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as timer:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			timer = timer.wait_event(events.CallbackQuery)
			timer = (await timer).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Triall Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{Quota}" "{timer}" "{iplim}" | trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(timer))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**      ⚡ ᴛʀɪᴀʟʟ ᴠᴍᴇꜱꜱ ᴀᴄᴄᴏᴜɴᴛ ⚡ **
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{z["ps"]}`
**➣ Domain :** `{z["add"]}`
**➣ User Quota :** `{Quota} GB`
**➣ Limit IP :** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ port TLS :** `222-1000`
**➣ Port NTLS :** `80, 8080, 8081-9999`
**➣ Port GRPC :** `443`
**➣ AlterId :** `0`
**➣ Security :** `auto`
**➣ NetWork :** `(WS) or (gRPC)`
**➣ Path :** `/vmess`
**➣ Service Name :** `vmess`
**➣ User ID :** `{z["id"]}`
**➣ Host XrayDNS :** `{HOST}`
**➣ PUB :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS TLS     ** 
**━━━━━━━━━━━━━━━━━**
`{b[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS NTLS    ** 
**━━━━━━━━━━━━━━━━━**
`{b[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VMESS GRPC    **
**━━━━━━━━━━━━━━━━━**
`{b[2].strip("'")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{DOMAIN}:81/vmess-{z["ps"]}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired :** `{timer} Minutes`
** 🤖 ©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴠᴍᴇꜱꜱ ᴍᴇɴᴜ","vmess")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#RENEW VMESS
@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def renew_vmess(event):
	async def renew_vmess_(event):
	  
		x = subprocess.check_output("cat /etc/vmess/.vmess.db | grep '###' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as CLIENT_NUMBER:
			await event.respond('**Select one:**')
			CLIENT_NUMBER = CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			CLIENT_NUMBER = (await CLIENT_NUMBER).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond('**Exp (Days):**')
			masaaktif = masaaktif.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			masaaktif = (await masaaktif).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Renew Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{CLIENT_NUMBER}" "{masaaktif}" | renewws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#Delete Vmess
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
	  
		x = subprocess.check_output("cat /etc/vmess/.vmess.db | grep '###' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as CLIENT_NUMBER:
			await event.respond('**Select one:**')
			CLIENT_NUMBER = CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			CLIENT_NUMBER = (await CLIENT_NUMBER).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Delete Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{CLIENT_NUMBER}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MEMBER VMESS
@bot.on(events.CallbackQuery(data=b'member-vmess'))
async def member_vmess(event):
	async def member_vmess_(event):
	  
		cmd = f'member-ws-bot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await member_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MENU VMESS
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" ᴛʀɪᴀʟʟ ᴠᴍᴇꜱꜱ ","trial-vmess"),
Button.inline(" ᴄʀᴇᴀᴛᴇ ᴠᴍᴇꜱꜱ ","create-vmess")],
[Button.inline(" ᴅᴇʟᴇᴛᴇ ᴠᴍᴇꜱꜱ ","delete-vmess"),
Button.inline(" ʀᴇɴᴇᴡ ᴠᴍᴇꜱꜱ ","renew-vmess")],
[Button.inline(" ᴍᴇᴍʙᴇʀ ᴠᴍᴇꜱꜱ ","cek-vmess")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**   ⚡𝙑𝙈𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝙈𝙀𝙉𝙐 ⚡**
**━━━━━━━━━━━━━━━━━**
**  💻 Service:** `VMESS`
**  🌎 ISP:** `{z["isp"]}`
**  🏢 Country:** `{z["country"]}`
**  🔗 Host:** `{DOMAIN}`
**  🤖 ©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
** TOTAL ACCOUNT VMESS  :** `{vms.strip()}` Account
**━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)