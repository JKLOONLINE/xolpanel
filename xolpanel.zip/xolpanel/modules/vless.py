from xolpanel import *

#CREATE VLESS
@bot.on(events.NewMessage(pattern=r"(?:.addvl|/addvl)$"))
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			masaaktif = masaaktif.wait_event(events.CallbackQuery)
			masaaktif = (await masaaktif).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{user}" "{masaaktif}" "{Quota}" "{iplim}" | addvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(masaaktif))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**       ⚡ ᴘʀᴇᴍɪᴜᴍ ᴠʟᴇꜱꜱ ᴀᴄᴄᴏᴜɴᴛ ⚡**
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{user}`
**➣ Domain :** `{DOMAIN}`
**➣ User Quota  :** `{Quota} GB`
**➣ Limit IP :** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ port TLS :** `222-1000`
**➣ Port NTLS :** `80, 8080, 8081-9999`
**➣ NetWork :** `(WS) or (gRPC)`
**➣ Service Name :** `vless`
**➣ Host XrayDNS:** `{HOST}`
**➣ User ID :** `{uuid}`
**➣ Path Vless :** `/vless `
**➣ PUB:** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS TLS     ** 
**━━━━━━━━━━━━━━━━━**
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS NTLS     ** 
**━━━━━━━━━━━━━━━━━**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS GRPC     ** 
**━━━━━━━━━━━━━━━━━**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{DOMAIN}:81/vless-{user}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired :** `{later}`
**➣  🤖©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴠʟᴇꜱꜱ ᴍᴇɴᴜ","vless")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#RENEW VLESS
@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def renew_vless(event):
	async def renew_vless_(event):
	  
		x = subprocess.check_output("cat /etc/vless/.vless.db | grep '#&' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as CLIENT_NUMBER:
			await event.respond('**Select one:**')
			CLIENT_NUMBER = CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			CLIENT_NUMBER = (await CLIENT_NUMBER).raw_text
		async with bot.conversation(chat) as masaaktif:
			await event.respond("**Extend (Days):**")
			masaaktif = masaaktif.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			masaaktif = (await masaaktif).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Renew Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{CLIENT_NUMBER}" "{masaaktif}" | renewvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#DELETE VLESS
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
	  
		x = subprocess.check_output("cat /etc/vless/.vless.db | grep '#&' | cut -d ' ' -f 2-3 | column -t | nl -s ' .      '",shell=True).decode("ascii")
		print(x)
		await event.edit (x)
		async with bot.conversation(chat) as masaaktif:
			await event.respond("**Extend (Days):**")
			masaaktif = masaaktif.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			masaaktif = (await masaaktif).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Delete Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{masaaktif}" | delvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			 today = DT.date.today()
			 exp = today + DT.timedelta(days=int(masaaktif))
			 #msg =
#		await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#TRIALL addvl
@bot.on(events.NewMessage(pattern=r"(?:.trialvl|/trialvl)$"))
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as Quota:
			await event.respond("**Quota:**")
			Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			Quota = (await Quota).raw_text
		async with bot.conversation(chat) as iplim:
			await event.respond("**Limit IP:**")
			iplim = iplim.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			iplim = (await iplim).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Minutes ","10"),
Button.inline(" 15 Minutes ","15")],
[Button.inline(" 30 Minutes ","30"),
Button.inline(" 60 Minutes ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(2)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		cmd = f'printf "%s\n" "{exp}" "{Quota}" "{iplim}" | trialvless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("vless://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("vless://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**       ⚡ ᴛʀɪᴀʟʟ ᴠʟᴇꜱꜱ ᴀᴄᴄᴏᴜɴᴛ ⚡**
**━━━━━━━━━━━━━━━━━**
**➣ Remarks :** `{remarks}`
**➣ Domain :** `{DOMAIN}`
**➣ User Quota  :** `{Quota} GB`
**➣ Limit IP :** `{iplim} IP`
**➣ Port DNS :** `443, 53`
**➣ port TLS :** `222-1000`
**➣ Port NTLS :** `80, 8080, 8081-9999`
**➣ NetWork :** `(WS) or (gRPC)`
**➣ Service Name :** `vless`
**➣ Host XrayDNS:** `{HOST}`
**➣ User ID :** `{uuid}`
**➣ Path Vless :** `/vless `
**➣ PUB:** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS TLS     ** 
**━━━━━━━━━━━━━━━━━**
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS NTLS     ** 
**━━━━━━━━━━━━━━━━━**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**                   VLESS GRPC     ** 
**━━━━━━━━━━━━━━━━━**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**               FORMAT OPENCLASH ** 
**━━━━━━━━━━━━━━━━━**
`https://{DOMAIN}:81/vless-{remarks}.txt`
**━━━━━━━━━━━━━━━━━**
**➣ Expired :** `{exp} Minutes`
**➣ 🤖©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
"""
			await event.respond(msg,buttons=[[Button.inline("🔙ᴠʟᴇꜱꜱ ᴍᴇɴᴜ","vless")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#MENU VLESS
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
[Button.inline(" ᴛʀɪᴀʟʟ ᴠʟᴇꜱꜱ ","trial-vless"),
Button.inline(" ᴄʀᴇᴀᴛᴇ ᴠʟᴇꜱꜱ ","create-vless")],
[Button.inline(" ᴅᴇʟᴇᴛᴇ ᴠʟᴇꜱꜱ ","delete-vless"),
Button.inline(" ʀᴇɴᴇᴡ ᴠʟᴇꜱꜱ ","renew-vless")],
[Button.inline(" ᴍᴇᴍʙᴇʀ ᴠʟᴇꜱꜱ ","member-vless")],
[Button.inline("🔙ᴍᴀɪɴ ᴍᴇɴᴜ","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vl = f' cat /etc/vless/.vless.db | grep "#&" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**   ⚡𝙑𝙇𝙀𝙎𝙎 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝙈𝙀𝙉𝙐 ⚡**
**━━━━━━━━━━━━━━━━━**
**  💻 Service:** `VLESS`
**  🌎 ISP:** `{z["isp"]}`
**  🏢 Country:** `{z["country"]}`
**  🔗 Host:** `{DOMAIN}`
**  🤖 ©JENGKOLONLONE**
**━━━━━━━━━━━━━━━━━**
** TOTAL ACCOUNT VLESS  :** `{vls.strip()}` Account
**━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
