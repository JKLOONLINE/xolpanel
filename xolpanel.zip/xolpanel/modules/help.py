from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.help|/help)$"))
@bot.on(events.CallbackQuery(data=b'cmds-list'))
async def cmds_list(event):
	async def cmds_list_(event):
		cmd = 'help-bot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**━━━━━━━━━━━━━━━━━**
**             COMMANDS LIST**
**━━━━━━━━━━━━━━━━━**
**❏   List Simpel Commands Bot **
**├•  Vmess Created .addws**
**├•  Trojan Created .addtr**
**├•  SSH Created .addssh**
**├•  Vless Created .addvl**
**├•  Trial SSH Created .trialssh**
**├•  Trial Vmess Created .trialws**
**├•  Trial Vless Created .trialvl**
**└•  Trial Trojan Created .trialtr **
**  --  Restart Xray Service  .restart **
**  --  Reboot Servers  .reboot**
**  --  Info Service VPS  .info **
** 🤖 ©ᴅᴇʟᴛᴀᴘʀᴏᴊᴇᴄᴛ**
**━━━━━━━━━━━━━━━━━**

""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cmds_list_(event)
	else:
		await event.answer("Access Denied",alert=True)
